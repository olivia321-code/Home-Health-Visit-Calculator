
from flask import Flask, render_template_string, request

skilled_needs = [('Complex wound care (VAC, >1 wound, packing, debridement)', 3), ('New ostomy or catheter teaching', 3), ('IV therapy or injections', 3), ('New diabetic teaching', 3), ('New heart failure education with daily weights', 2), ('Pain management with medication adjustments', 2), ('Lab draws for unstable condition', 2), ('Medication management only', 1), ('Routine monitoring of stable condition', 1)]
risk_factors = [('Unstable vitals in last 72 hrs', 3), ('Multiple recent hospitalizations (last 30 days)', 3), ('High fall risk (per screening)', 2), ('Cognitive impairment affecting self-care', 2), ('Lives alone without reliable caregiver', 2), ('Caregiver unable/unwilling to assist', 2), ('Language or communication barrier', 1)]

template = '\n<!DOCTYPE html>\n<html>\n<head>\n    <title>Home Health Visit Calculator</title>\n    <meta name="viewport" content="width=device-width, initial-scale=1">\n    <style>\n        body { font-family: Arial, sans-serif; padding: 10px; background-color: #f9f9f9; }\n        h2 { text-align: center; }\n        .section { margin-bottom: 20px; padding: 10px; background: white; border-radius: 5px; }\n        label { display: block; margin: 5px 0; }\n        button { width: 100%; padding: 10px; font-size: 16px; background: #28a745; color: white; border: none; border-radius: 5px; }\n        .result { margin-top: 20px; padding: 15px; background: #dff0d8; border-radius: 5px; }\n    </style>\n</head>\n<body>\n\n<h2>Home Health Visit Frequency Calculator</h2>\n\n<form method="POST">\n    <div class="section">\n        <h3>Skilled Needs</h3>\n        {% for item, points in skilled_needs %}\n            <label><input type="checkbox" name="points" value="{{ points }}"> {{ item }} ({{ points }} pts)</label>\n        {% endfor %}\n    </div>\n\n    <div class="section">\n        <h3>Risk Factors</h3>\n        {% for item, points in risk_factors %}\n            <label><input type="checkbox" name="points" value="{{ points }}"> {{ item }} ({{ points }} pts)</label>\n        {% endfor %}\n    </div>\n\n    <button type="submit">Calculate</button>\n</form>\n\n{% if total is not none %}\n<div class="result">\n    <h3>Total Points: {{ total }}</h3>\n    <p><strong>Suggested Frequency:</strong> {{ frequency }}</p>\n    <p><strong>Taper Plan:</strong> {{ taper }}</p>\n</div>\n{% endif %}\n\n</body>\n</html>\n'

def get_frequency(points):
    if points >= 8:
        return ("4–5 visits per week", "Gradually taper every 1–2 weeks based on stability")
    elif points >= 5:
        return ("2–3 visits per week", "Taper to 1–2/week by week 4")
    elif points >= 3:
        return ("1–2 visits per week", "Taper to every other week if stable")
    else:
        return ("1 visit every 1–2 weeks", "Reassess need each recert period")

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    total = None
    frequency = None
    taper = None
    if request.method == "POST":
        selected_points = request.form.getlist("points")
        total = sum(int(p) for p in selected_points)
        frequency, taper = get_frequency(total)
    return render_template_string(template, skilled_needs=skilled_needs, risk_factors=risk_factors, total=total, frequency=frequency, taper=taper)

if __name__ == "__main__":
    app.run(debug=True)
